import { Component, OnInit } from '@angular/core';
import { HotelService } from '../services/hotelService';
import { PaginationService } from '../services/pagination.service'
import { UserService } from '../services/userService';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { user } from '../models/user';
import { Hotels } from '../models/hotels';
import { Bookings } from '../models/bookings';
import { Rooms } from '../models/rooms';
import { Router } from "@angular/router";


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  title = 'VoyageTravels'
  currentMenu = "Dashboard";
  bookings: Bookings[];
  hotels: Hotels[];
  hotelrooms: Rooms[]
  bookingStatus = "false";

  currentUser: user;


  constructor(private userService: UserService, private router: Router, private hotelService: HotelService) { 
    this.currentUser = JSON.parse(localStorage.getItem('currentTravelUser'));
  }

  ngOnInit() {
      this.getBookings();

      this.hotelService.hotels().subscribe(data => {this.hotels = data},
              error => this.hotels = []);
  }

  logout() {
      this.userService.logout();
      this.router.navigateByUrl('/login')
  }

  hotelRooms(hotelId) {
      this.hotelService.hotelRooms(hotelId).subscribe(data => this.hotelrooms = data,
              error => this.hotelrooms = []);
  }

  bookRoom(roomId) {
      this.hotelService.bookHotelRoom(roomId, this.currentUser.id).subscribe(data => { },
              error => this.hotelrooms = []);
      this.setBookingStatus();
  }

  getBookings() {
        this.hotelService.bookings(this.currentUser.id).subscribe((data) => this.bookings = data,
              error => this.bookings = []);
  }

  setBookingStatus() {
    this.bookingStatus = "true";
  }

  changeMenu(menu) {
    if(menu=="dashboard") {
      this.hotelrooms = [];
      this.getBookings();
      this.bookingStatus = "false"
    }
  	this.currentMenu = menu;
  }

  cCSubmit() {
        

        
    }

}
