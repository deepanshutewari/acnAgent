import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { LoginModule } from './login/login.module';
import { LoginComponent } from './login/login.component';

import { RegisterModule } from './registration/register.module';
import { RegisterComponent } from './registration/register.component';


import { HomeModule } from './home/home.module';
import { HomeComponent } from './home/home.component';
import { CurrencyRestCallsService } from './services/currency-rest-call-service';
import { HotelService } from './services/hotelService';
import { AuthFilter } from './services/authFilter';
import { UserService } from './services/userService';
import { PaginationService } from './services/pagination.service'
import { HttpClientModule } from '@angular/common/http';
import { SocialComponent } from './social/social.component';

import {
    SocialLoginModule,
    AuthServiceConfig,
    FacebookLoginProvider,
} from "angular-6-social-login";

const appRoutes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'home', component: HomeComponent, canActivate: [AuthFilter] },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'converter', component: LoginComponent },
  { path: 'logout', component: LoginComponent }
];


export function getAuthServiceConfigs() {
  let config = new AuthServiceConfig(
      [
        {
          id: FacebookLoginProvider.PROVIDER_ID,
          provider: new FacebookLoginProvider("275409999225871")
        }
      ]
  );
  return config;
}

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    RegisterComponent,
    SocialComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    RouterModule.forRoot(
      appRoutes
    ),
    HomeModule,
    LoginModule,
    RegisterModule,
    HttpClientModule,
    SocialLoginModule
  ],
  providers: [CurrencyRestCallsService, PaginationService, UserService, AuthFilter, HotelService, 
  {
      provide: AuthServiceConfig,
      useFactory: getAuthServiceConfigs
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }
