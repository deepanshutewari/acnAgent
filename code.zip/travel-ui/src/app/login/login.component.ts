import { Component, OnInit  } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from "@angular/router";
import { UserService } from '../services/userService';
import { user } from '../models/user';

@Component({
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit{
  title = 'VoyageTravels';
  lSubmit = false;
  loginForm: FormGroup;
  badCredentials = false;

  constructor(private userService: UserService, private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
       this.loginForm = this.formBuilder.group({
            email: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.required]]
        }); 
  }

  get lForm() { return this.loginForm.controls; }

  onSubmit() {
        this.lSubmit = true;
		    if (this.loginForm.invalid) {
            return;
        }

        const user: user = {
               email: this.loginForm.controls.email.value,
               password: this.loginForm.controls.password.value
        }

        this.userService.UserLogin(user).subscribe(data => {this.router.navigateByUrl('/home')},
              error => this.badCredentials = true);
    }
}
