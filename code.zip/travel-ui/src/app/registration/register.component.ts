import { Component, OnInit  } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from "@angular/router";
import { UserService } from '../services/userService';
import { HttpHeaders } from '@angular/common/http';

import { user } from '../models/user';


@Component({
  templateUrl: './register.component.html'
})
export class RegisterComponent implements OnInit{
  title = 'VoyageTravels';
  rSubmit = false;
  registerForm: FormGroup;
  passmismatch = false;
  registerFailure = false;


  constructor(private userService: UserService, private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
       this.registerForm = this.formBuilder.group({
            username: ['', [Validators.required]],
            email: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.required]],
            confirmpassword: ['', [Validators.required]]
        }); 
  }

  get rForm() { return this.registerForm.controls; }

  onSubmit() {
        this.rSubmit = true;
		    if (this.registerForm.invalid) {
            return;
        }
        if (this.registerForm.controls.confirmpassword.value == this.registerForm.controls.password.value){
        	  const user: user = {
               userName: this.registerForm.controls.username.value,
               email: this.registerForm.controls.email.value,
               password: this.registerForm.controls.password.value
            }
            this.userService.RegisterUser(user).subscribe(data => this.router.navigateByUrl('/login'),
              error => this.registerFailure = true);
        } else {
        	this.passmismatch = true;
        }
    }
}
