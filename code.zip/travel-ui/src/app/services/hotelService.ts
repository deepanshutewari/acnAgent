import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Hotels } from '../models/hotels';
import { Bookings } from '../models/bookings';
import { Rooms } from '../models/rooms';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class HotelService {
	apiURL = 'http://localhost:8181';
	endpoint = ""
	
	constructor(private http: HttpClient) { }
	
	bookings(userId) {
	   this.endpoint = "/bookings/"+userId;
	   return this.http.get<Bookings[]>(this.apiURL+this.endpoint);
	}

	hotels() {
	   this.endpoint = "/hotels/";
	   return this.http.get<Hotels[]>(this.apiURL+this.endpoint);
	}

	hotelRooms(hotelId) {
	   this.endpoint = "/hotel/rooms/"+hotelId;
	   return this.http.get<Rooms[]>(this.apiURL+this.endpoint);
	}

	bookHotelRoom(roomId, userId) {
	   this.endpoint = "/bookings/room/"+roomId+"/"+userId;
	   return this.http.post(this.apiURL+this.endpoint, {});
	}

}