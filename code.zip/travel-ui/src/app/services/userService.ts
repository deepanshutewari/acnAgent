import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { user } from '../models/user';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class UserService {
	apiURL = 'http://localhost:8181';
	endpoint = ""
	
	constructor(private http: HttpClient) { }
	
	RegisterUser(params) {
	   this.endpoint = "/registration";
	   return this.http.post(this.apiURL+this.endpoint, params, httpOptions);
	}

	UserLogin(params) {
	   this.endpoint = "/login";
	   return this.http.post<user>(this.apiURL+this.endpoint, params, httpOptions)
	   .pipe(map(user => {
	            if (user) {
                	user.password = "****";
                    localStorage.setItem('currentTravelUser', JSON.stringify(user));
                }

                return user;
            }));
	}

	logout() {
        localStorage.removeItem('currentTravelUser');
    }

    storeFbToken(fbData) {
    	this.endpoint = "/fb/token";
	   return this.http.post<user>(this.apiURL+this.endpoint, fbData, httpOptions).pipe(map(user => {
	            if (user) {
                	user.password = "****";
                    localStorage.setItem('currentTravelUser', JSON.stringify(user));
                }

                return user;
            }));
	}
}