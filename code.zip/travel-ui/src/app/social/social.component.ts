import {Component, OnInit} from '@angular/core';
import {
    AuthService,
    FacebookLoginProvider
} from 'angular-6-social-login';

import { UserService } from '../services/userService';
import { Router } from "@angular/router";
 
@Component({
  selector: 'app-signin',
  templateUrl: './social.component.html',
  styleUrls: ['./social.component.scss']
})
 
 
export class SocialComponent implements OnInit {
 
  constructor(private userService: UserService, private socialAuthService: AuthService, private router: Router ) {}

  ngOnInit() {

  }
  
  socialSignIn(socialPlatform : string) {
    let socialPlatformProvider;
    if(socialPlatform == "facebook"){
      socialPlatformProvider = FacebookLoginProvider.PROVIDER_ID;
    }
    
    this.socialAuthService.signIn(socialPlatformProvider).then(
      (userData) => {
        this.userService.storeFbToken(userData).subscribe(data => {this.router.navigateByUrl('/home')},
              error => alert("Error storing Fb token"));
      }
    );
  }
  
}