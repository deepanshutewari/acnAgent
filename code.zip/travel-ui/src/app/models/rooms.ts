export class Rooms {
  hotelId: number;
  numberOfBeds: number;
  price: number;
  roomId: number;
  roomType: string;
  totalRooms: number;
}