export class user {
  id?: number;
  userName?: string;
  email: string;
  password: string;
  sessionId?: string;
}