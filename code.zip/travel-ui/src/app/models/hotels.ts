export class Hotels {
  address: string;
  city: string;
  country: string;
  hoteName: string;
  hotelId: number
  pincode: string;
}