package com.travel.voyage.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel.voyage.entity.Bookings;
import com.travel.voyage.repository.BookingRepository;

@Service
public class BookingService {

	BookingRepository bookingRepository;

	@Autowired
	public BookingService(BookingRepository bookingRepository) {
		super();
		this.bookingRepository = bookingRepository;
	}

	public BookingService() {

	}

	public List<Bookings> getBookingsByUserId(Integer id) {
		return bookingRepository.findBookingsByCustId(id);
	}
	
	public String bookHotelRoom(int roomId, int userId) {
		Bookings booking = new Bookings();
		booking.setCustId(userId);
		booking.setRoomId(roomId);
		booking.setHotelId(1);
		booking.setCheckinDate(new Date());
		booking.setCheckoutDate(new Date());
		bookingRepository.save(booking);
		
		return "Booking confirmed";
	}

	public void setRepository(BookingRepository repository) {
		this.bookingRepository = repository;
	}
}
