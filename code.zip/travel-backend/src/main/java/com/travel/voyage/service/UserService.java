package com.travel.voyage.service;

/**
 * @author ajaykumar
 * 
 * Service class for
 * user login and registration
 *
 */

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel.voyage.entity.FbUser;
import com.travel.voyage.entity.User;
import com.travel.voyage.repository.FbUserRepository;
import com.travel.voyage.repository.UserRepository;

@Service
public class UserService {

	UserRepository userRepository;
	FbUserRepository fbUserRepository;

	@Autowired
	public UserService(UserRepository userRepository, FbUserRepository fbUserRepository) {
		super();
		this.userRepository = userRepository;
		this.fbUserRepository = fbUserRepository;
	}

	public UserService() {

	}

	public void setReviewRepository(UserRepository repository) {
		this.userRepository = repository;
	}

	public User createUser(User user) {
		user = userRepository.save(user);
		return user;
	}
	
	public User createFbUser(FbUser fbUser) {
		FbUser existingUser = fbUserRepository.findById(fbUser.getId());
		User user = new User();
		if (existingUser != null) {
			existingUser.setToken(fbUser.getToken());
			fbUserRepository.save(existingUser);
			
			user.setEmail(existingUser.getEmail());
			user.setUserName(existingUser.getName());
			user.setId(existingUser.getFbUserId());
			user.setPassword(existingUser.getToken());
		} else {
			fbUser = fbUserRepository.save(fbUser);
			user.setEmail(fbUser.getEmail());
			user.setUserName(fbUser.getName());
			user.setId(fbUser.getFbUserId());
			user.setPassword(fbUser.getToken());
		}
		
		return user;
	}

	public User loginUser(User user) {
		return userRepository.findByEmailAndPassword(user.getEmail(), user.getPassword());
	}

//	public User findOne(Integer userId) {
//		User user = userRepository.findOne(userId);
//		return user;
//	}

}