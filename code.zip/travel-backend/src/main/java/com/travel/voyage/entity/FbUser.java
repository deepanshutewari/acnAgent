package com.travel.voyage.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@Entity
@Table(name="FB_USERS")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class FbUser {
	
	@Id
	@GeneratedValue
	@Column(name="fb_user_id")
	private Integer fbUserId;
	@NotNull
    @Column(name="fb_id")
	private String id;
	@NotNull
	@Column(name="email")
	private String email;
	@NotNull
	@Column(name="name")
	private String name;
	@NotNull
	@Column(name="provider")
	private String provider;
	@NotNull
	@Column(name="token")
	private String token;
	@NotNull
	@Column(name="image")
	private String image;
	
	
	public Integer getFbUserId() {
		return fbUserId;
	}
	public void setFbUserId(Integer fbUserId) {
		this.fbUserId = fbUserId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProvider() {
		return provider;
	}
	public void setProvider(String provider) {
		this.provider = provider;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	

}
