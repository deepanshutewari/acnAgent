package com.travel.voyage.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.travel.voyage.entity.Hotels;

public interface HotelRepository extends JpaRepository<Hotels, Integer>{

	public List<Hotels> findAll();

}
