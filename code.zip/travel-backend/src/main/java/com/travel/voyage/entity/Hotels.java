package com.travel.voyage.entity;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@Entity
@Table(name="Hotels")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class Hotels {
    @Id
	@GeneratedValue
	@Column(name="hotel_id")
	private Integer hotelId;
    @NotNull
    @Column(name="hotel_name")
    private String hoteName;
    @NotNull
    @Column(name="address")
    private String address;
    @NotNull
    @Column(name="city")
    private String city;
    @NotNull
    @Column(name="country")
    private String country;
    @NotNull
    @Column(name="pincode")
    private String pincode;
    
//    @OneToMany(mappedBy="hotelId")
//    private Set<Rooms> rooms;
    
	
//	public Set<Rooms> getRooms() {
//		return rooms;
//	}
//
//
//	public void setRooms(Set<Rooms> rooms) {
//		this.rooms = rooms;
//	}


	public Hotels(){
		
	}


	public Integer getHotelId() {
		return hotelId;
	}


	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}


	public String getHoteName() {
		return hoteName;
	}


	public void setHoteName(String hoteName) {
		this.hoteName = hoteName;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getPincode() {
		return pincode;
	}


	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
}
