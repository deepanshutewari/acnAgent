package com.travel.voyage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelWebAppApplication.class, args);
	}
}
