package com.travel.voyage;

public interface Authenticate {

}
