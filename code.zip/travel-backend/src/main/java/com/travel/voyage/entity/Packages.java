package com.travel.voyage.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@Entity
@Table(name="Packages")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class Packages {
    @Id
	@GeneratedValue
	@Column(name="package_id")
	private Integer bookingId;
    @NotNull
    @Column(name="origin")
    private String origin;
    @NotNull
    @Column(name="destination")
    private String destination;
    @NotNull
    @Column(name="no_od_days")
    private Integer numberOfDays;
    @NotNull
    @Column(name="hotel_id")
    private Integer hotel_id;
    @NotNull
    @Column(name="room_id")
    private Integer room_id;
    
    public Integer getRoom_id() {
		return room_id;
	}
	public void setRoom_id(Integer room_id) {
		this.room_id = room_id;
	}
	@NotNull
    @Column(name="price")
    private Double price;
	public Integer getBookingId() {
		return bookingId;
	}
	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Integer getNumberOfDays() {
		return numberOfDays;
	}
	public void setNumberOfDays(Integer numberOfDays) {
		this.numberOfDays = numberOfDays;
	}
	public Integer getHotel_id() {
		return hotel_id;
	}
	public void setHotel_id(Integer hotel_id) {
		this.hotel_id = hotel_id;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
    
}
