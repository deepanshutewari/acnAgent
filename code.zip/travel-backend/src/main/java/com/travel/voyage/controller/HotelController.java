package com.travel.voyage.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.travel.voyage.entity.Hotels;
import com.travel.voyage.entity.Rooms;
import com.travel.voyage.service.HotelService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class HotelController {

	HotelService hotelService;
	private static final Logger LOGGER = LoggerFactory.getLogger(HotelController.class);

	@Autowired
	public HotelController(HotelService hotelService) {
		super();
		this.hotelService = hotelService;
	}

	public HotelController() {

	}

	public void setBookingService(HotelService hotelService) {
		this.hotelService = hotelService;
	}

	@RequestMapping(value = "/hotels", method = RequestMethod.GET)
	public List<Hotels> getHotels() {
		
		return hotelService.getHotels();
	}
	
	@RequestMapping(value = "/hotel/rooms/{hotelId}", method = RequestMethod.GET)
	public List<Rooms> getRooms(@PathVariable int hotelId) {
		
		return hotelService.getHotelRooms(hotelId);
	}
	
}
