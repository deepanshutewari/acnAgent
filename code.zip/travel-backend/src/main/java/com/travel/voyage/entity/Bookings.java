package com.travel.voyage.entity;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@Entity
@Table(name="Bookings")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class Bookings {
    @Id
	@GeneratedValue
	@Column(name="booking_id")
	private Integer bookingId;
    @NotNull
    @Column(name="cust_id")
    private Integer custId;
    @NotNull
    @Column(name="hotel_id")
    private Integer hotelId;
    @NotNull
    @Column(name="room_id")
    private Integer roomId;
    @NotNull
    @Column(name="checkin_date")
    private Date checkinDate;
    @NotNull
    @Column(name="checkout_date")
    private Date checkoutDate;
    
	public Integer getBookingId() {
		return bookingId;
	}
	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}
	public Integer getCustId() {
		return custId;
	}
	public void setCustId(Integer custId) {
		this.custId = custId;
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public Integer getRoomId() {
		return roomId;
	}
	public void setRoomId(Integer roomId) {
		this.roomId = roomId;
	}
	public Date getCheckinDate() {
		return checkinDate;
	}
	public void setCheckinDate(Date checkinDate) {
		this.checkinDate = checkinDate;
	}
	public Date getCheckoutDate() {
		return checkoutDate;
	}
	public void setCheckoutDate(Date checkoutDate) {
		this.checkoutDate = checkoutDate;
	}
	
}
