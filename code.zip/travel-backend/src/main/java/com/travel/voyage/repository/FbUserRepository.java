/**
 * 
 */
package com.travel.voyage.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.travel.voyage.entity.FbUser;


/**
 * @author adithya956
 *
 */
public interface FbUserRepository extends JpaRepository<FbUser, Integer> {
	
	
	FbUser findById(String id);
}


