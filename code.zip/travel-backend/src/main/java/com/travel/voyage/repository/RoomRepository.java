package com.travel.voyage.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.travel.voyage.entity.Rooms;

public interface RoomRepository extends JpaRepository<Rooms, Integer>{

	public List<Rooms> findRoomsByHotelId(Integer hotelId);

}
