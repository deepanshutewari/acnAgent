package com.travel.voyage.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@Entity
@Table(name="Rooms")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class Rooms {
    @Id
	@GeneratedValue
	@Column(name="room_id")
	private Integer roomId;
    
    @NotNull
    @Column(name="hotel_id")
    private Integer hotelId;
    
    public Integer getRoomId() {
		return roomId;
	}


	public void setRoomId(Integer roomId) {
		this.roomId = roomId;
	}


	public Integer getHotelId() {
		return hotelId;
	}


	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}


	public String getRoomType() {
		return roomType;
	}


	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}


	public Double getPrice() {
		return price;
	}


	public void setPrice(Double price) {
		this.price = price;
	}


	public Integer getNumberOfBeds() {
		return numberOfBeds;
	}


	public void setNumberOfBeds(Integer numberOfBeds) {
		this.numberOfBeds = numberOfBeds;
	}


	public Integer getTotalRooms() {
		return totalRooms;
	}


	public void setTotalRooms(Integer totalRooms) {
		this.totalRooms = totalRooms;
	}


	@NotNull
    @Column(name="room_type")
    private String roomType;
    @NotNull
    @Column(name="price")
    private Double price;
    @NotNull
    @Column(name="no_of_beds")
    private Integer  numberOfBeds;
    @NotNull
    @Column(name="total_rooms")
    private Integer totalRooms;
    
	
	public Rooms(){
		
	}


	
}
