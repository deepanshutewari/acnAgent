package com.travel.voyage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel.voyage.entity.Hotels;
import com.travel.voyage.entity.Rooms;
import com.travel.voyage.repository.HotelRepository;
import com.travel.voyage.repository.RoomRepository;

@Service
public class HotelService {

	HotelRepository hotelRepository;
	RoomRepository roomRepository;

	@Autowired
	public HotelService(HotelRepository hotelRepository, RoomRepository roomRepository) {
		super();
		this.hotelRepository = hotelRepository;
		this.roomRepository = roomRepository;
	}

	public HotelService() {

	}

	public List<Hotels> getHotels() {
		return hotelRepository.findAll();
	}
	
	public List<Rooms> getHotelRooms(Integer hotelId) {
		return roomRepository.findRoomsByHotelId(hotelId);
	}

	public void setRepository(HotelRepository hotelRepository, RoomRepository roomRepository) {
		this.hotelRepository = hotelRepository;
		this.roomRepository = roomRepository;
	}
}
