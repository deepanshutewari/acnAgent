package com.travel.voyage.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.travel.voyage.entity.Bookings;
import com.travel.voyage.service.BookingService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class BookingsController {

	BookingService bookingService;
	private static final Logger LOGGER = LoggerFactory.getLogger(BookingsController.class);

	@Autowired
	public BookingsController(BookingService bookingService) {
		super();
		this.bookingService = bookingService;
	}

	public BookingsController() {

	}

	public void setBookingService(BookingService bookingService) {
		this.bookingService = bookingService;
	}

	@RequestMapping(value = "/bookings/room/{roomId}/{userId}", method = RequestMethod.POST)
	public String bookRoom(@PathVariable int roomId, @PathVariable int userId) {
		
		return bookingService.bookHotelRoom(roomId, userId);
	}


	@RequestMapping(value = "/bookings/{userId}", method = RequestMethod.GET)
	public List<Bookings> GetBookings(@PathVariable int userId) {
		
		return bookingService.getBookingsByUserId(userId);
	}


}
